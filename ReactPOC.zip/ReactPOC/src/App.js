
import './App.css';
import { Routes, Route } from 'react-router-dom';
import SignIn from './components/signIn';
import SignUp from './components/signUp';
import Pricing from './components/homeComp';
import ProductPage from './components/productPage';
import ErrorPage from './components/pageNotFound';


function App() {

  const PrivateWrapper = ({ children }) => {
    const userDataLogin = localStorage.getItem("userDataLogin")
    return userDataLogin && userDataLogin.length ? children : <ErrorPage />;
  };

  return (
    <div className="App">
      <Routes>
        <Route exact={true} path="/" element={<SignIn />} />
        <Route exact={true} path="/SignUp" element={<SignUp />} />
        {/* <Route exact={true}
          path="/home"
          element={<Pricing />}
        /> */}
        <Route 
          path="/product"
          element={<ProductPage />}    
        />
        <Route
          path={"/home"}
          element={(
            <PrivateWrapper>
              <Pricing />
            </PrivateWrapper>
          )}
        />
        <Route path="*" element={<ErrorPage />} />

      </Routes>

    </div>
  );
}

export default App;
