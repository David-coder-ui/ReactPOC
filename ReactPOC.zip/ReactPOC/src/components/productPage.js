import React from 'react';
import { Box, Button, Typography } from '@mui/material';
import { blue } from '@mui/material/colors';
import ErrorPage from './pageNotFound'

const primary = blue[500]; // #f44336

 function Product() {
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'column',
        minHeight: '100vh',
        backgroundColor: primary,
      }}
    >
      <Typography variant="h1" style={{ color: 'white' }}>
      Product Details
      </Typography>
      <Typography variant="h6" style={{ color: 'white' }}>
        Product Summary
      </Typography>
    </Box>
  );
}

export default function ProductPage() {
    const userDataLogin=localStorage.getItem("userDataLogin")
    return userDataLogin && userDataLogin.length ? <Product /> : <ErrorPage/>;
  }